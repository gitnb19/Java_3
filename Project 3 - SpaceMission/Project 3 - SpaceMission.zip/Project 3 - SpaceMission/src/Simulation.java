import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.List;
import java.util.stream.Stream;

public class Simulation {
    List[] loadItems() {
        File file_phase1 = new File("phase-1.txt");
        System.out.println(file_phase1.exists());
        File file_phase2 = new File("phase-2.txt");
        System.out.println(file_phase2.exists());
        ArrayList<Item> fileInput_phase1 = new ArrayList<>();
        ArrayList<Item> fileInput_phase2 = new ArrayList<>();
        try {
            Scanner fileScanner_phase1 = new Scanner(file_phase1);
            while (fileScanner_phase1.hasNextLine()) {
                String line = fileScanner_phase1.nextLine();
                String lineSplit[] = line.split("=");
                Item item = new Item(lineSplit[0],Integer.valueOf(lineSplit[1]));
               fileInput_phase1.add(item);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Phase1 file was not found");
        }
        try {
            Scanner fileScanner_phase2 = new Scanner(file_phase2);
            while (fileScanner_phase2.hasNextLine()) {
                String line = fileScanner_phase2.nextLine();
                String lineSplit[] = line.split("=");
                Item item = new Item(lineSplit[0], Integer.valueOf(lineSplit[1]));
                fileInput_phase2.add(item);
            }
            int noOfItems_phase1 = fileInput_phase1.size();
            int noOfItems_phase2 = fileInput_phase2.size();
            System.out.println("ArrayList contents: Phase 2 " + fileInput_phase2);
        } catch (FileNotFoundException e) {
                System.out.println("Phase2 file was not found");
            }

        return new List[] {fileInput_phase1, fileInput_phase2};
    }

    List [] loadU1(List[] loadItemsU1) {

        ArrayList<U1> fileInput_loadU1_phase1 = new ArrayList<>();
        ArrayList<U1> fileInput_loadU1_phase2 = new ArrayList<>();

        Object itemRead = loadItemsU1[0].get(0);

        System.out.println("itemRead = " + itemRead);
        System.out.println("itemRead = " + itemRead.toString());
        System.out.println("1st Item Object in Simulation Class - Load U1 method " + itemRead);
        System.out.println("Reading from fileInput_phase1 Arraylist:");
        System.out.println("**********************" + ((Item) loadItemsU1[0].get(0)).weight);
        if (loadItemsU1[0].size() > 0) {
            U1 u1 = new U1();
            int totalWeightOfCargo = 0;
            Iterator<ArrayList> loadItemsU1_phase1_iterator = loadItemsU1[0].iterator();
            int itemCount = 0;
            int u1Count = 1;
            while (loadItemsU1_phase1_iterator.hasNext()) {
                    Object item1 = loadItemsU1[0].get(itemCount);
                    System.out.println("**********************" + ((Item) loadItemsU1[0].get(itemCount)).weight);
                    System.out.println("Item Count = " +itemCount);
                    //String name1 = item1.name;
                    //System.out.println(loadItemsU1[1]);
                    //totalWeightOfCargo = totalWeightOfCargo + item.weight;
                    if (totalWeightOfCargo > u1.maxCargoWeight) {
                        fileInput_loadU1_phase1.add(u1);
                        //u1 = null;
                    } else {
                        System.out.println("Else executed");
                        u1 = new U1();
                        u1Count = u1Count + 1;
                    }
                    itemCount = itemCount +1;

                }
                System.out.println("Number of U1 rockets needed for Phase 1 = " +u1Count);
            }
            return new List[]{fileInput_loadU1_phase1, fileInput_loadU1_phase2};
        }
    }

